package com.example.midtermcharity

import android.database.Cursor
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var etName: EditText
    private lateinit var etStudentId: EditText
    private lateinit var seekBarAge: SeekBar
    private lateinit var tvAgeLabel: TextView
    private lateinit var btnAdd: Button
    private lateinit var btnEdit: Button
    private lateinit var btnDelete: Button
    private lateinit var btnView: Button
    private lateinit var listViewStudents: ListView

    private var selectedAge: Int = 17
    private var selectedId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)

        etName = findViewById(R.id.etStudentName)
        etStudentId = findViewById(R.id.etStudentId)
        seekBarAge = findViewById(R.id.seekBarAge)
        tvAgeLabel = findViewById(R.id.tvAgeLabel)
        btnAdd = findViewById(R.id.btnAdd)
        btnEdit = findViewById(R.id.btnEdit)
        btnDelete = findViewById(R.id.btnDelete)
        btnView = findViewById(R.id.btnView)
        listViewStudents = findViewById(R.id.listViewStudents)

        seekBarAge.max = 33
        seekBarAge.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                selectedAge = progress + 17
                tvAgeLabel.text = "Student Age: $selectedAge"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnAdd.setOnClickListener {
            val name = etName.text.toString().trim()
            val studentId = etStudentId.text.toString().trim()
            if (name.isEmpty() || studentId.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val success = dbHelper.insertData(name, studentId, selectedAge)
            if (success) {
                Toast.makeText(this, "Data Inserted Successfully", Toast.LENGTH_SHORT).show()
                loadDataToList()
                clearFields()
            } else {
                Toast.makeText(this, "Insertion Failed", Toast.LENGTH_SHORT).show()
            }
        }

        btnView.setOnClickListener {
            loadDataToList()
        }

        listViewStudents.setOnItemClickListener { parent, _, position, _ ->
            val itemText = parent.getItemAtPosition(position) as String
            val parts = itemText.split(".")
            if (parts.isNotEmpty()) {
                selectedId = parts[0].trim()
                Toast.makeText(this, "Selected ID: $selectedId", Toast.LENGTH_SHORT).show()
            }
        }

        btnEdit.setOnClickListener {
            if (selectedId.isEmpty()) {
                Toast.makeText(this, "Please select an item from list first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val name = etName.text.toString().trim()
            val studentId = etStudentId.text.toString().trim()
            val success = dbHelper.updateData(selectedId, name, studentId, selectedAge)
            if (success) {
                Toast.makeText(this, "Data Updated", Toast.LENGTH_SHORT).show()
                loadDataToList()
                clearFields()
            } else {
                Toast.makeText(this, "Update Failed", Toast.LENGTH_SHORT).show()
            }
        }

        btnDelete.setOnClickListener {
            if (selectedId.isEmpty()) {
                Toast.makeText(this, "Please select an item from list first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val deletedRows = dbHelper.deleteData(selectedId)
            if (deletedRows > 0) {
                Toast.makeText(this, "Data Deleted", Toast.LENGTH_SHORT).show()
                loadDataToList()
                clearFields()
            } else {
                Toast.makeText(this, "Deletion Failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadDataToList() {
        val cursor: Cursor = dbHelper.getAllData()
        if (cursor.count == 0) {
            listViewStudents.adapter = null
            showAlert("Info", "No data found in database.")
            return
        }

        val listData = ArrayList<String>()
        while (cursor.moveToNext()) {
            val id = cursor.getString(0)
            val name = cursor.getString(1)
            val studentId = cursor.getString(2)
            val age = cursor.getString(3)
            listData.add("$id. $name ($studentId) - Age: $age")
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listData)
        listViewStudents.adapter = adapter
    }

    private fun clearFields() {
        etName.text.clear()
        etStudentId.text.clear()
        seekBarAge.progress = 0
        tvAgeLabel.text = "Student Age: 17"
        selectedId = ""
    }

    private fun showAlert(title: String, message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.setPositiveButton("OK", null)
        builder.show()
    }
}